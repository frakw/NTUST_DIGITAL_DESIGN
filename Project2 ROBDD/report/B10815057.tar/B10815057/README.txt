輸出dot檔:	$./robdd <pla檔名> <dot檔名>
EXAMPLE: 	$./robdd input.pla output.dot
輸出png檔:	$dot -T png <dot檔名> > <png檔名>
EXAMPLE:	$dot -T png output.dot > output.png