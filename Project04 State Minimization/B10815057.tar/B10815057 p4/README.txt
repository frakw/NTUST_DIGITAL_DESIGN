編譯:		$g++ -o smin smin.cpp
輸出dot檔:	$./smin <輸入kiss檔名> <輸出kiss檔名> <dot檔名>
EXAMPLE: 	$./smin input.kiss output.kiss output.dot
輸出png檔:	$dot -T png <dot檔名> > <png檔名>
EXAMPLE:	$dot -T png output.dot > output.png